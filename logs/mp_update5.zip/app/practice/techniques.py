"""The technique library: the user's own practice techniques, indexed by the problem they address.

A card is chosen from (problem, stage) and ranked by what has helped before (see passages.rank_techniques).
`helper` names a small tool shown on the card (rendered by web/practice.js).
Stages: "new" = still learning the notes, "build" = getting it reliable / up to tempo, "keep" = memory and polish.
Users can override or extend this list with DATA_DIR/techniques.json (same shape).
"""
import json
from . import DATA_DIR

PROBLEMS = [
    {"id": "notes", "name": "Notes not learned yet"},
    {"id": "fingering", "name": "Fingering unsettled"},
    {"id": "uneven", "name": "Uneven / rhythm"},
    {"id": "speed", "name": "Can't reach tempo"},
    {"id": "jumps", "name": "Jumps / leaps"},
    {"id": "memory", "name": "Memory slips"},
    {"id": "seams", "name": "Transitions between sections"},
    {"id": "coordination", "name": "Hands together / polyrhythm"},
    {"id": "sound", "name": "Sound, voicing, shape"},
    {"id": "tension", "name": "Tension / heaviness"},
    {"id": "pedal", "name": "Blurry / relying on pedal"},
]

TECHNIQUES = [
    {"id": "last-note", "name": "Fingering from the last note", "problems": ["fingering", "notes"], "stages": ["new"],
     "how": "Decide the fingering of the last note first. Add one note before it at a time, keeping the fingering fixed, until the whole figure is built backwards.",
     "helper": "counter"},
    {"id": "block", "name": "Block chords", "problems": ["notes", "jumps", "speed", "coordination", "memory"], "stages": ["new", "build"],
     "how": "Play each hand position as a single chord: first out of tempo (just the shapes), then in tempo on the beat, moving between positions as fast as possible.",
     "helper": "metronome"},
    {"id": "backchain", "name": "Backward chaining", "problems": ["memory", "notes", "seams"], "stages": ["new", "build", "keep"],
     "how": "Start with the last bar only. Each time it is secure, start one bar earlier and play through to the end. The end is always the best-known part.",
     "helper": "chain-back"},
    {"id": "focalchain", "name": "Focal chaining", "problems": ["memory", "seams", "notes"], "stages": ["build", "keep"],
     "how": "Pick the hardest bar (the focus). Play it, then extend one bar before or after, alternating, always passing through the focus.",
     "helper": "chain-focal"},
    {"id": "bursts", "name": "Burst permutations", "problems": ["speed", "uneven"], "stages": ["build"],
     "how": "Play groups as fast bursts that stop on a note (ffff. = four fast notes, then hold). Shift where the stop falls so every note is once a landing point.",
     "helper": "bursts"},
    {"id": "fastslow", "name": "Fast/slow permutations", "problems": ["uneven", "speed"], "stages": ["build"],
     "how": "Play continuously in long–short patterns (f = fast, s = slow), then rotate the pattern so each note is fast in one pass and slow in another.",
     "helper": "fastslow"},
    {"id": "softloud", "name": "Soft/loud permutations", "problems": ["uneven", "sound", "tension"], "stages": ["build", "keep"],
     "how": "Accent one note per group (sssL), then move the accent. Everything else as soft as possible.",
     "helper": "softloud"},
    {"id": "dynamics", "name": "Exaggerated dynamics, slightly under tempo", "problems": ["sound", "memory"], "stages": ["build", "keep"],
     "how": "Play every dynamic and hairpin twice as big as written, a little under tempo. Then play it as written: what remains is shape.",
     "helper": "metronome"},
    {"id": "nopedal", "name": "No pedal", "problems": ["pedal", "sound", "notes"], "stages": ["new", "build", "keep"],
     "how": "Play without any pedal and make the legato and the voicing with the fingers alone.", "helper": None},
    {"id": "legato", "name": "Legato overlap", "problems": ["sound", "pedal", "tension"], "stages": ["build", "keep"],
     "how": "Exaggerate finger legato: each key stays down a moment after the next one sounds (overlapping), listening to the connection.", "helper": None},
    {"id": "quiet", "name": "As quiet as possible", "problems": ["tension", "sound", "memory"], "stages": ["build", "keep"],
     "how": "Play the whole passage as quietly as you can without dropping notes. Control over the key descent shows up immediately.", "helper": None},
    {"id": "landing", "name": "Stop on the first bar of the next section", "problems": ["seams", "memory"], "stages": ["build", "keep"],
     "how": "Never stop at the end of the passage: always continue to the first beat of the next section, so the seam is practised every time.",
     "helper": "landing"},
    {"id": "hemiola", "name": "Regroup against the metronome", "problems": ["uneven", "coordination", "memory"], "stages": ["build"],
     "how": "Set the metronome to accent a different grouping than the notation (e.g. 2+2+2 against 3+3, or every 5th note) and play the passage against it.",
     "helper": "regroup"},
    {"id": "slowlisten", "name": "Super slow, listening", "problems": ["notes", "sound", "tension", "memory"], "stages": ["new", "build", "keep"],
     "how": "Play far below tempo, with the full sound and every dynamic, listening to each note arrive. Slow enough that nothing is automatic.",
     "helper": "metronome"},
    {"id": "story", "name": "A story for the motif", "problems": ["memory", "sound"], "stages": ["new", "build", "keep"],
     "how": "Give the passage a picture or story (who is speaking, what happens at each turn). Write it in the passage notes; it is shown whenever you open the passage.",
     "helper": "story"},
    {"id": "mirror", "name": "Mirrored hands (around D or A♭)", "problems": ["coordination", "fingering", "notes"], "stages": ["new", "build"],
     "how": "Play one hand's line in the other hand, mirrored around D (or A♭): the keyboard is symmetric there, so the fingering and shape carry over exactly.",
     "helper": None},
    {"id": "shadow", "name": "Shadowing jumps", "problems": ["jumps"], "stages": ["new", "build"],
     "how": "Practise only the movement: from the note before the jump, move to hover over the target silently and fast, then land. Then add the sound.",
     "helper": None},
    {"id": "lookaway", "name": "Looking away / not turning the page", "problems": ["memory", "jumps"], "stages": ["keep"],
     "how": "Play without looking at the hands, or without the score (hide it with H). For page turns: keep the previous page up and play through.",
     "helper": "hide"},
    {"id": "poly", "name": "Polyrhythm grid", "problems": ["coordination"], "stages": ["new", "build"],
     "how": "Count the common grid (e.g. 6 for 3 against 2). Hands separately on the grid, then together; vary which pulse the metronome clicks.",
     "helper": "poly"},
    {"id": "onetheme", "name": "One instance of a theme per day", "problems": ["memory"], "stages": ["build", "keep"],
     "how": "When a theme comes back several times, give its passages the same Theme name: only one of them is scheduled per day, in rotation, so the versions don't blur.",
     "helper": "theme"},
]

def load():
    """(problems, techniques), with the user's override file merged in by id."""
    probs, techs = list(PROBLEMS), list(TECHNIQUES)
    f = DATA_DIR / "techniques.json"
    if f.exists():
        try:
            extra = json.loads(f.read_text(encoding="utf-8"))
            for key, lst in (("problems", probs), ("techniques", techs)):
                for item in extra.get(key, []):
                    i = next((k for k, x in enumerate(lst) if x["id"] == item.get("id")), None)
                    if i is None: lst.append(item)
                    else: lst[i] = {**lst[i], **item}
        except Exception:
            pass
    return probs, techs
