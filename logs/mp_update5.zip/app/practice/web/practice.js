// Practice mode: today's plan, the active passage (technique card, helpers, logging), cold tests, the metronome.
import { useState, useEffect, useRef, useMemo } from "./vendor/hooks.js";
import { html, api, fmtMin, store, player, toast, rangeLabel } from "./lib.js";
import { Metronome, bursts, fastSlow, softLoud, chainSteps, lcm } from "./metronome.js";

export const metro = new Metronome();
window.metro = metro;
const RATINGS = [[1, "Again", "broke down"], [2, "Hard", "got through, with slips"], [3, "Good", "solid"], [4, "Easy", "effortless"]];
const STATE_NAME = { working: "working", maintenance: "testing" };

function useMetro() { const [, f] = useState(0); useEffect(() => metro.onChange(() => f(x => x + 1)), []); }
export const passageName = (M, p) => p.name || rangeLabel(M, p.a, p.b) || "Passage";
const pname = (p) => p.name || p.label || "Passage";

// bars of a passage in notated order
export function passageBars(M, p) {
  if (!M || !p) return []; const oa = M.order[p.a], ob = M.order[p.b];
  if (oa == null || ob == null) return []; return M.seq.slice(Math.min(oa, ob), Math.max(oa, ob) + 1);
}

// ------------------------------------------------------------------ score overlay (inside the page SVG)
export function PassageOverlay({ M, bars, passages, active, W, H, k, onPick }) {
  const onPage = new Set(bars.map(b => b.id));
  const out = [];
  for (const p of passages || []) {
    const ids = passageBars(M, p).filter(id => onPage.has(id)); if (!ids.length) continue;
    const on = active && active.id === p.id;
    for (const id of ids) {
      const [x0, , x1, y1] = M.byId[id].box;
      out.push(html`<rect class=${"pz " + (p.state || "") + (on ? " on" : "")} x=${x0 * W + 2 * k} y=${y1 * H - (on ? 7 : 5) * k} width=${Math.max(2, (x1 - x0) * W - 4 * k)} height=${(on ? 6 : 4) * k}
        rx=${2 * k} onClick=${e => { e.stopPropagation(); onPick(p); }}><title>${p.name || "passage"} (${STATE_NAME[p.state] || p.state})</title></rect>`);
    }
  }
  return html`<g>${out}</g>`;
}
export function HideOverlay({ M, bars, hide, W, H, k }) {
  if (!hide) return null; const ids = new Set(passageBars(M, hide));
  return html`<g>${bars.filter(b => ids.has(b.id)).map(b => { const [x0, y0, x1, y1] = b.box;
    return html`<rect class="hid" x=${x0 * W} y=${y0 * H - 4 * k} width=${(x1 - x0) * W} height=${(y1 - y0) * H + 8 * k} />`; })}</g>`;
}

// ------------------------------------------------------------------ cold test dialog
export function TestDialog({ M, passage, onClose, onDone, setHide }) {
  const [hideScore, setHideScore] = useState(store.get("testHide", false));
  const [failed, setFailed] = useState(false); const [probs, setProbs] = useState([]);
  useEffect(() => { if (hideScore) setHide({ a: passage.a, b: passage.b }); return () => setHide(null); }, [hideScore]);
  useEffect(() => { api.get("/api/practice/techniques").then(d => setProbs(d.problems)); }, []);
  const rate = async (r) => {
    const v = await api.send("POST", `/api/passages/${passage.id}/log`, { kind: "test", rating: r });
    if (r === 1) { setFailed(true); onDone(v, true); return; }
    toast(v.state === "maintenance" ? `${pname(passage)}: ${RATINGS[r - 1][1]} · next test ${new Date(v.due * 1000).toLocaleDateString(undefined, { month: "short", day: "numeric" })}`
      : `${pname(passage)}: ${RATINGS[r - 1][1]} (logged; it stays in daily work until you mark it ready)`);
    onDone(v); onClose();
  };
  useEffect(() => {
    const key = e => { if (failed) return; if (/^[1-4]$/.test(e.key)) { e.preventDefault(); e.stopPropagation(); rate(+e.key); } };
    window.addEventListener("keydown", key, true); return () => window.removeEventListener("keydown", key, true);
  }, [failed]);
  const setProblem = async (id) => { await api.send("PATCH", `/api/passages/${passage.id}`, { problem: id }); onDone(null); onClose(); };
  return html`<div class="scrim" onClick=${e => e.target === e.currentTarget && onClose()}><div class="dialog">
    <h3>Cold test · ${passageName(M, passage)} <span class="muted" style="font-weight:400">${rangeLabel(M, passage.a, passage.b)}</span></h3>
    ${!failed ? html`
      <p class="hint" style="margin-top:0">Play it once, without warming up on it first. Keep going through slips as you would on stage.</p>
      <label class="hint" style="display:flex;align-items:center;gap:6px"><input type="checkbox" checked=${hideScore} onChange=${e => { setHideScore(e.target.checked); store.set("testHide", e.target.checked); }} /> hide the passage on the score</label>
      <div class="ratings">${RATINGS.map(([n, name, d]) => html`<button class=${"btn rate r" + n} onClick=${() => rate(n)}><kbd>${n}</kbd><b>${name}</b><span>${d}</span></button>`)}</div>`
    : html`<p class="hint" style="margin-top:0">It goes back to daily work. What was the main problem? (This picks the technique card.)</p>
      <div class="tools">${probs.map(p => html`<button class=${"btn" + (passage.problem === p.id ? " on" : "")} onClick=${() => setProblem(p.id)}>${p.name}</button>`)}</div>`}
    <div class="actions"><button class="btn" onClick=${onClose}>${failed ? "Skip" : "Cancel"} <kbd>Esc</kbd></button></div></div></div>`;
}

// ------------------------------------------------------------------ the panel
export function PracticePanel({ M, data, sel, passages, active, openPassage, setActive, reloadPassages, setSel, hide, setHide, keyRef, startTest, version }) {
  const [tab, setTab] = useState("today");
  const [plan, setPlan] = useState(null);
  const [lib, setLib] = useState(null);
  const loadPlan = (b) => api.get("/api/practice/today" + (b ? `?budget=${b}` : "")).then(setPlan);
  useEffect(() => { loadPlan(); }, [version]);
  useEffect(() => { api.get("/api/practice/techniques").then(setLib); }, [version]);
  return html`
    <div class="card"><h2><div class="seg mini"><button class=${tab === "today" ? "on" : ""} onClick=${() => setTab("today")}>Today</button><button class=${tab === "piece" ? "on" : ""} onClick=${() => setTab("piece")}>This piece${passages.length ? ` (${passages.length})` : ""}</button></div>
        <span class="r">${tab === "today" && plan ? html`<span class="muted">${Math.round(plan.total)} min planned ·</span>
          <select class="mini" value=${plan.budget} onChange=${e => loadPlan(e.target.value)} title="how long you have today">${[15, 20, 30, 40, 60, 90, 120, 180].map(b => html`<option value=${b}>${b} min</option>`)}</select>` : null}</span></h2>
      ${tab === "today" ? html`<${Today} M=${M} plan=${plan} active=${active} openPassage=${openPassage} startTest=${startTest} />`
        : html`<${PieceList} M=${M} data=${data} passages=${passages} active=${active} openPassage=${openPassage} onPerf=${() => loadPlan()} />`}
    </div>
    <${PassageCard} M=${M} data=${data} p=${active} sel=${sel} setSel=${setSel} lib=${lib} reload=${() => { reloadPassages(); loadPlan(); }}
      hide=${hide} setHide=${setHide} keyRef=${keyRef} startTest=${startTest} setActive=${setActive}
      next=${plan && active ? plan.items.find(it => it.in_budget && it.id !== active.id) : null}
      goNext=${(it) => { openPassage(it); if (it.kind === "test") setTimeout(() => startTest(it), 60); }} />
    <${MetroCard} active=${active} />`;
}

function Suggestions({ plan, openPassage }) {
  const [gone, setGone] = useState(store.get("dismissedJoins", []));
  const list = (plan.suggestions || []).filter(x => !gone.includes(x.ids.join("+")));
  if (!list.length) return null;
  const join = async (x) => { const p = await api.send("POST", `/api/pieces/${x.piece_id}/passages`, { a: x.a, b: x.b, name: x.name });
    if (!p.error) { toast("Joined: practise them as one passage now"); openPassage(p); } };
  const dismiss = (x) => { const g = [...gone, x.ids.join("+")]; setGone(g); store.set("dismissedJoins", g); };
  return html`${list.map(x => html`<div class="qrow sugg" title="both are secure in cold tests: time to play them as one">
    <span class="kind join">Join</span><span class="nm">${x.name}</span><span class="muted ell">${x.label || ""}</span>
    <span class="row"><button class="btn small" onClick=${() => join(x)}>Join</button><button class="btn small ghost" onClick=${() => dismiss(x)}>×</button></span></div>`)}`;
}

function Today({ M, plan, active, openPassage, startTest }) {
  if (!plan) return html`<div class="hint">…</div>`;
  const items = plan.items; const inb = items.filter(i => i.in_budget); const later = items.length - inb.length;
  if (!items.length) return html`<div class="hint">${plan.done.length ? `Done for today: ${plan.done.length} passage${plan.done.length > 1 ? "s" : ""}. ` : ""}${statLine(plan.stats) ? statLine(plan.stats) + ". " : ""}Nothing else is due.
    Select bars on the score and press <kbd>P</kbd> to make a passage to work on.</div><${Suggestions} plan=${plan} openPassage=${openPassage} />`;
  const [next, ...rest] = inb;
  const go = (it) => { openPassage(it); if (it.kind === "test") setTimeout(() => startTest(it), 60); };
  return html`
    <div class=${"next" + (active && active.id === next.id ? " on" : "")} onClick=${() => go(next)}>
      <span class=${"kind " + next.kind}>${next.kind === "test" ? "Test" : "Work"}</span>
      <div class="grow1"><b>${pname(next)}</b> <span class="muted">${next.piece_title}</span><div class="hint">${next.reason}</div></div>
      <button class="btn primary small" onClick=${e => { e.stopPropagation(); go(next); }}>Start</button></div>
    ${rest.slice(0, 4).map(it => html`<div class=${"qrow" + (active && active.id === it.id ? " on" : "")} onClick=${() => go(it)}>
      <span class=${"kind " + it.kind}>${it.kind === "test" ? "Test" : "Work"}</span><span class="nm">${pname(it)}</span><span class="muted ell">${it.piece_title}</span><span class="muted">${Math.round(it.est)}′</span></div>`)}
    <${Suggestions} plan=${plan} openPassage=${openPassage} />
    <div class="hint" style="margin-top:3px">${[rest.length > 4 ? `+${rest.length - 4} more` : "", later ? `${later} past your time today` : "",
      plan.done.length ? `${plan.done.length} done` : "", plan.rested.length ? `${plan.rested.length} resting (theme rotation)` : "", statLine(plan.stats)].filter(Boolean).join(" · ")}</div>`;
}

function statLine(st) {
  if (!st || !(st.today || st.week)) return "";
  const hm = m => m >= 60 ? `${Math.floor(m / 60)} h ${m % 60 ? (m % 60) + " min" : ""}`.trim() : `${m} min`;
  return [`today ${hm(st.today)}`, `this week ${hm(st.week)}`, st.streak > 1 ? `${st.streak} days in a row` : ""].filter(Boolean).join(", ");
}

function PieceList({ M, data, passages, active, openPassage, onPerf }) {
  const [perf, setPerf] = useState(data.piece.perf_date || "");
  useEffect(() => setPerf(data.piece.perf_date || ""), [data.piece.id]);
  const savePerf = async (v) => { setPerf(v); await api.send("PATCH", `/api/pieces/${data.piece.id}`, { perf_date: v || null }); onPerf(); };
  const perfRow = html`<label class="hint row" style="margin-bottom:4px" title="raises priority and target retention as the date approaches">Performance date
    <input type="date" class="mini" value=${perf} onChange=${e => savePerf(e.target.value)} />${perf ? html`<button class="btn small" onClick=${() => savePerf("")}>×</button>` : null}</label>`;
  if (!passages.length) return html`${perfRow}<div class="hint">No passages in this piece yet. Select bars (click, Shift+click) and press <kbd>P</kbd>.</div>`;
  return html`${perfRow}<div class="plist2">${passages.map(p => html`<div class=${"qrow" + (active && active.id === p.id ? " on" : "")} onClick=${() => openPassage(p)}>
    <span class=${"kind " + (p.state === "maintenance" ? "test" : "work")}>${STATE_NAME[p.state]}</span><span class="nm">${passageName(M, p)}</span>
    <span class="muted ell">${rangeLabel(M, p.a, p.b)}</span><span class="muted">${p.worked_today || p.tested_today ? "✓" : ""}</span></div>`)}</div>`;
}

// ------------------------------------------------------------------ the active passage
function PassageCard({ M, data, p, sel, setSel, lib, reload, hide, setHide, keyRef, startTest, setActive, next, goNext }) {
  const [t0, setT0] = useState(Date.now()); const [, tick] = useState(0);
  const [logging, setLogging] = useState(false); const [ti, setTi] = useState(0);
  useEffect(() => { setT0(Date.now()); setLogging(false); setTi(0); }, [p && p.id]);
  useEffect(() => { const i = setInterval(() => tick(x => x + 1), 1000); return () => clearInterval(i); }, []);
  useEffect(() => { setTi(0); }, [p && p.problem]);
  const patch = async (body) => { await api.send("PATCH", `/api/passages/${p.id}`, body); reload(); };
  const cards = useMemo(() => rankedCards(lib, p), [lib, p && p.problem, p && p.stage, p && p.state, p && p.sessions]);
  const card = cards.length ? cards[ti % cards.length] : null;
  keyRef.current = (e) => {
    if (!p) return false; const k = e.key;
    if (k === "t" || k === "T") { startTest(p); return true; }
    if ((k === "n" || k === "N") && next) { goNext(next); return true; }
    if (k === "[" && cards.length) { setTi(i => (i - 1 + cards.length) % cards.length); return true; }
    if (k === "]" && cards.length) { setTi(i => (i + 1) % cards.length); return true; }
    return false;
  };
  if (!p) return html`<div class="card grow"><h2>Passage</h2><div class="hint">Select bars on the score (click, then Shift+click) and press <kbd>P</kbd> to save them as a passage.
    Passages you are working on come back every day; when one is ready, it moves to cold tests, spaced out as it gets secure.</div></div>`;
  const secs = (Date.now() - t0) / 1000;
  const selDiffers = sel && (sel.a !== p.a || sel.b !== p.b);
  const tempo = (k, v) => patch({ [k]: v === "" ? null : +v });
  return html`<div class="card grow passage">
    <h2>Passage <span class=${"pill " + p.state}>${STATE_NAME[p.state]}</span>
      <span class="r"><span class="stars" title="priority">${[1, 2, 3].map(n => html`<button class=${n <= (p.priority || 2) ? "on" : ""} onClick=${() => patch({ priority: n })}>★</button>`)}</span>
        <button class="btn small" title="delete this passage" onClick=${async () => { if (confirm(`Delete the passage "${passageName(M, p)}" and its practice history?`)) { await api.send("DELETE", `/api/passages/${p.id}`); setActive(null); reload(); } }}>×</button></span></h2>
    <div class="row"><input class="pname" value=${p.name || ""} placeholder=${rangeLabel(M, p.a, p.b)} onChange=${e => patch({ name: e.target.value })} />
      <span class="muted nowrap">${rangeLabel(M, p.a, p.b)}</span>
      ${selDiffers ? html`<button class="btn small" title="make the passage the selected bars" onClick=${() => patch({ a: sel.a, b: sel.b })}>= selection</button>` : null}</div>
    <div class="row small-fields">
      <label>♩ best<input type="number" value=${p.best_tempo ?? ""} onChange=${e => tempo("best_tempo", e.target.value)} /></label>
      <label>goal<input type="number" value=${p.goal_tempo ?? ""} onChange=${e => tempo("goal_tempo", e.target.value)} /></label>
      <label title="passages with the same theme are rotated: one per day">theme<input value=${p.theme || ""} placeholder="—" onChange=${e => patch({ theme: e.target.value.trim() || null })} /></label>
    </div>
    <div class="row"><select value=${p.problem || ""} onChange=${e => patch({ problem: e.target.value || null })} style="flex:1;min-width:0">
        <option value="">Problem… (picks a technique)</option>${(lib ? lib.problems : []).map(x => html`<option value=${x.id}>${x.name}</option>`)}</select>
      <select value=${p.stage || ""} onChange=${e => patch({ stage: e.target.value || null })} title="stage (auto from how long you've worked on it)">
        <option value="">${{ new: "learning", build: "building", keep: "keeping" }[p.auto_stage]} (auto)</option><option value="new">learning</option><option value="build">building</option><option value="keep">keeping</option></select></div>
    ${card ? html`<div class="tech">
        <div class="row"><b style="flex:1">${card.name}</b>${cards.length > 1 ? html`<button class="btn small" onClick=${() => setTi(i => (i - 1 + cards.length) % cards.length)}>‹ <kbd>[</kbd></button><span class="muted">${(ti % cards.length) + 1}/${cards.length}</span><button class="btn small" onClick=${() => setTi(i => (i + 1) % cards.length)}><kbd>]</kbd> ›</button>` : null}</div>
        <div class="how">${card.how}</div>
        ${card._rank ? html`<div class="hint">helped ${Math.round(card._rank.score * 100)}% of ${card._rank.n} time${card._rank.n > 1 ? "s" : ""} for this problem</div>` : null}
        <${Helper} kind=${card.helper} tech=${card} M=${M} p=${p} patch=${patch} setSel=${setSel} hide=${hide} setHide=${setHide} />
      </div>` : null}
    <${NotesHistory} p=${p} patch=${patch} compact=${!!card} />
    ${(p.worked_today || p.tested_today) && next && !logging ? html`<div class="row nextrow" style="margin-top:auto"><span class="hint">Done here for today.</span><span class="spacer"></span>
      <button class="btn primary ell" style="max-width:70%" title="the next item in today's plan" onClick=${() => goNext(next)}>Next: ${next.name || next.label} › <kbd>N</kbd></button></div>` : null}
    <div class="row" style=${(p.worked_today || p.tested_today) && next && !logging ? "padding-top:6px" : "margin-top:auto;padding-top:6px"}>
      ${logging ? html`<${LogWork} p=${p} secs=${secs} card=${card} onDone=${() => { setLogging(false); reload(); }} onCancel=${() => setLogging(false)} />` : html`
        <span class="muted timer" title="time on this passage">${fmtMin(secs)}</span><span class="spacer"></span>

        ${p.state === "working" ? html`<button class="btn" title="log this session" onClick=${() => setLogging(true)}>${p.worked_today ? "✓ Log more" : "Done for today"}</button>` : null}
        <button class="btn" onClick=${() => startTest(p)}>Test <kbd>T</kbd></button>
        ${p.state === "working" ? html`<button class="btn" title="stop daily work; it comes back as cold tests" onClick=${async () => { await api.send("POST", `/api/passages/${p.id}/log`, { kind: "graduate" }); toast("Moved to cold tests: first one tomorrow"); reload(); }}>Ready →</button>`
          : html`<button class="btn" onClick=${async () => { await api.send("POST", `/api/passages/${p.id}/log`, { kind: "unlearn" }); reload(); }}>Back to work</button>`}`}
    </div></div>`;
}

function NotesHistory({ p, patch, compact }) {
  const [hist, setHist] = useState([]);
  useEffect(() => { api.get(`/api/passages/${p.id}/history`).then(h => Array.isArray(h) && setHist(h)); }, [p.id, p.last_worked, p.last_tested, p.state]);
  const day = t => new Date(t * 1000).toLocaleDateString(undefined, { month: "short", day: "numeric" });
  const line = l => l.kind === "test" ? `cold test: ${RATINGS[(l.rating || 1) - 1][1]}` : l.kind === "work" ? `worked ${l.minutes ? Math.round(l.minutes) + " min" : ""}${l.technique ? " · " + l.technique : ""}${l.tempo ? " · ♩" + l.tempo : ""}${l.helped === 1 ? " · helped" : l.helped === -1 ? " · didn't help" : ""}`
    : l.kind === "graduate" ? "moved to cold tests" : l.kind === "unlearn" ? "back to daily work" : l.kind;
  return html`<div class="notes-hist">
    <textarea rows=${compact ? 1 : 3} placeholder="Notes, fingering, the story of this passage…" value=${p.notes || ""} onChange=${e => patch({ notes: e.target.value })}></textarea>
    <div class="hist">${hist.length ? hist.slice(0, 12).map(l => html`<div><span class="muted">${day(l.t)}</span> ${line(l)}</div>`) : html`<span class="hint">${compact ? "No practice logged yet." : "No practice logged yet. Choose the problem above to get a technique."}</span>`}</div></div>`;
}

function rankedCards(lib, p) {
  if (!lib || !p || !p.problem) return [];
  const stage = p.stage || p.auto_stage; const ranks = (lib.ranks && lib.ranks[p.problem]) || {};
  const cs = lib.techniques.filter(t => (t.problems || []).includes(p.problem)).map(t => ({ ...t, _rank: ranks[t.id] }));
  // stage matches first; then untried (0.55) vs tried (Beta mean); ties keep library order
  const score = t => ((t.stages || []).includes(stage) ? 1 : 0) + (t._rank ? t._rank.score : 0.55);
  return cs.map((t, i) => [t, i]).sort((x, y) => score(y[0]) - score(x[0]) || x[1] - y[1]).map(x => x[0]);
}

function LogWork({ p, secs, card, onDone, onCancel }) {
  const [min, setMin] = useState(Math.max(1, Math.round(secs / 60))); const [tempo, setTempo] = useState(""); const [helped, setHelped] = useState(null);
  const save = async () => {
    await api.send("POST", `/api/passages/${p.id}/log`, { kind: "work", minutes: +min, tempo: tempo ? +tempo : null, technique: card ? card.id : null, problem: p.problem, helped });
    toast(`${pname(p)}: logged ${min} min`); onDone();
  };
  return html`<div class="logwork">
    <label>min<input type="number" value=${min} onInput=${e => setMin(e.target.value)} /></label>
    <label>♩ reached<input type="number" value=${tempo} placeholder=${p.best_tempo || ""} onInput=${e => setTempo(e.target.value)} /></label>
    ${card ? html`<span class="hint">helped?</span><span class="seg mini">${[[1, "yes"], [0, "same"], [-1, "no"]].map(([v, l]) => html`<button class=${helped === v ? "on" : ""} onClick=${() => setHelped(helped === v ? null : v)}>${l}</button>`)}</span>` : null}
    <span class="spacer"></span><button class="btn small" onClick=${onCancel}>×</button><button class="btn small primary" onClick=${save}>Save</button></div>`;
}

// ------------------------------------------------------------------ helpers on the technique card
function Helper({ kind, tech, M, p, patch, setSel, hide, setHide }) {
  const hs = p.helper_state || {}; const st = hs[tech.id] || {};
  const save = (v) => patch({ helper_state: { ...hs, [tech.id]: { ...st, ...v } } });
  if (kind === "bursts" || kind === "fastslow" || kind === "softloud") {
    const m = st.m || (kind === "fastslow" ? 3 : 4); const done = new Set(st.done || []);
    const pats = kind === "bursts" ? bursts(m) : kind === "fastslow" ? fastSlow(m) : softLoud(m, !!st.two);
    const toggle = s => { const d = new Set(done); d.has(s) ? d.delete(s) : d.add(s); save({ done: [...d] }); };
    return html`<div class="helper"><div class="row hint">${kind === "bursts" ? "burst length" : "notes per group"}
        <select class="mini" value=${m} onChange=${e => save({ m: +e.target.value, done: [] })}>${[2, 3, 4, 5, 6, 8].map(x => html`<option value=${x}>${x}</option>`)}</select>
        ${kind === "softloud" ? html`<label class="row"><input type="checkbox" checked=${!!st.two} onChange=${e => save({ two: e.target.checked })} /> two loud</label>` : null}
        <span class="spacer"></span>${done.size}/${pats.length} done ${done.size ? html`<button class="btn small" onClick=${() => save({ done: [] })}>reset</button>` : null}</div>
      <div class="pats">${pats.map(s => html`<button class=${"pat" + (done.has(s) ? " done" : "")} onClick=${() => toggle(s)}>${s}</button>`)}</div></div>`;
  }
  if (kind === "chain-back" || kind === "chain-focal") {
    const bars = passageBars(M, p); const n = bars.length;
    const focus = Math.min(n - 1, st.focus ?? Math.floor(n / 2));
    const steps = chainSteps(n, kind === "chain-back" ? "back" : "focal", focus); const i = Math.min(steps.length - 1, st.step || 0);
    const [lo, hi] = steps[i] || [0, 0];
    const show = (j) => { const [a, b] = steps[j]; setSel({ a: bars[a], b: bars[b], anchor: bars[a] }); save({ step: j }); };
    if (n < 2) return html`<div class="helper hint">Make the passage at least two bars long to chain it.</div>`;
    return html`<div class="helper"><div class="row"><span>Step ${i + 1} of ${steps.length}: <b>${rangeLabel(M, bars[lo], bars[hi])}</b></span><span class="spacer"></span>
        <button class="btn small" onClick=${() => show(Math.max(0, i - 1))}>‹</button><button class="btn small primary" onClick=${() => show(Math.min(steps.length - 1, i + 1))}>secure → next</button></div>
      <div class="chain">${bars.map((id, j) => html`<i class=${(j >= lo && j <= hi ? "in" : "") + (kind === "chain-focal" && j === focus ? " focus" : "")}
          title=${M.label(id)} onClick=${() => kind === "chain-focal" ? save({ focus: j, step: 0 }) : null}></i>`)}</div>
      ${kind === "chain-focal" ? html`<div class="hint">Click a cell to set the focus bar.</div>` : null}</div>`;
  }
  if (kind === "landing") {
    const nb = M.seq[M.order[p.b] + 1];
    return html`<div class="helper row">${nb ? html`<button class="btn small" onClick=${() => setSel({ a: p.a, b: nb, anchor: p.a })}>Select through ${M.label(nb)} (the landing bar)</button>` : html`<span class="hint">This passage ends the piece.</span>`}</div>`;
  }
  if (kind === "hide") return html`<div class="helper row"><button class=${"btn small" + (hide ? " on" : "")} onClick=${() => setHide(hide ? null : { a: p.a, b: p.b })}>${hide ? "Show the passage" : "Hide the passage on the score"} <kbd>H</kbd></button></div>`;
  if (kind === "counter") {
    const c = st.count || 0;
    return html`<div class="helper row"><span>Notes built: <b>${c}</b></span><button class="btn small" onClick=${() => save({ count: c + 1 })}>+1</button><button class="btn small" onClick=${() => save({ count: Math.max(0, c - 1) })}>−1</button><button class="btn small" onClick=${() => save({ count: 0 })}>reset</button></div>`;
  }
  if (kind === "story") return html`<div class="helper"><textarea rows="2" placeholder="The story or picture for this passage…" value=${p.notes || ""} onChange=${e => patch({ notes: e.target.value })}></textarea></div>`;
  if (kind === "theme") return html`<div class="helper hint">Type the same name in "theme" above for each instance of the theme.</div>`;
  if (kind === "regroup") {
    const g = st.group || 2, sub = st.sub || 2;
    const apply = (ng, ns) => { save({ group: ng, sub: ns }); metro.set({ mode: "regroup", group: ng, sub: ns }); };
    return html`<div class="helper row">Accent every <select class="mini" value=${g} onChange=${e => apply(+e.target.value, sub)}>${[2, 3, 4, 5, 6, 7].map(x => html`<option value=${x}>${x}</option>`)}</select>
      of <select class="mini" value=${sub} onChange=${e => apply(g, +e.target.value)}>${[1, 2, 3, 4, 6].map(x => html`<option value=${x}>${x}</option>`)}</select> notes per beat
      <button class=${"btn small" + (metro.on && metro.mode === "regroup" ? " on" : "")} onClick=${() => { apply(g, sub); metro.toggle(); }}>${metro.on && metro.mode === "regroup" ? "Stop" : "Start"} <kbd>M</kbd></button></div>`;
  }
  if (kind === "poly") return html`<${PolyHelper} st=${st} save=${save} />`;
  if (kind === "metronome") {
    const g = p.goal_tempo;
    return html`<div class="helper row hint">${g ? html`Set the metronome to <button class="btn small" onClick=${() => metro.set({ bpm: g * 0.5, mode: "beat" })}>50%</button><button class="btn small" onClick=${() => metro.set({ bpm: g * 0.7, mode: "beat" })}>70%</button><button class="btn small" onClick=${() => metro.set({ bpm: g * 0.9, mode: "beat" })}>90%</button> of the goal (♩ ${g})`
      : "Set a goal tempo above to get quick settings here."}</div>`;
  }
  return null;
}

function PolyHelper({ st, save }) {
  useMetro();
  const p = st.p || 3, q = st.q || 2, voice = st.voice || "both", vary = st.vary || 0; const n = lcm(p, q);
  const apply = (o) => { const s = { p, q, voice, vary, ...o }; save(s); metro.set({ mode: "poly", poly: { p: s.p, q: s.q, voice: s.voice, vary: s.vary } }); };
  const on = metro.on && metro.mode === "poly";
  return html`<div class="helper">
    <div class="row"><select class="mini" value=${p} onChange=${e => apply({ p: +e.target.value })}>${[2, 3, 4, 5, 6, 7, 8, 9].map(x => html`<option value=${x}>${x}</option>`)}</select> against
      <select class="mini" value=${q} onChange=${e => apply({ q: +e.target.value })}>${[2, 3, 4, 5, 6, 7, 8].map(x => html`<option value=${x}>${x}</option>`)}</select>
      <select class="mini" value=${voice} onChange=${e => apply({ voice: e.target.value })}><option value="both">click both</option><option value="p">only ${p}</option><option value="q">only ${q}</option><option value="grid">the grid</option></select>
      <label class="row hint" title="rotate what the metronome clicks every 2 cycles"><input type="checkbox" checked=${!!vary} onChange=${e => apply({ vary: e.target.checked ? 2 : 0 })} /> vary</label>
      <button class=${"btn small" + (on ? " on" : "")} onClick=${() => { apply({}); metro.toggle(); }}>${on ? "Stop" : "Start"}</button></div>
    <div class="grid" style=${`grid-template-columns:repeat(${n},1fr)`}>
      ${Array.from({ length: n }, (_, j) => html`<i class=${j % (n / p) === 0 ? "on" : ""}>${j % (n / p) === 0 ? j / (n / p) + 1 : ""}</i>`)}
      ${Array.from({ length: n }, (_, j) => html`<i class=${j % (n / q) === 0 ? "on q" : ""}>${j % (n / q) === 0 ? j / (n / q) + 1 : ""}</i>`)}
    </div><div class="hint">Count the ${n} grid cells; top row = ${p}, bottom row = ${q}.</div></div>`;
}

// ------------------------------------------------------------------ metronome strip
function MetroCard({ active }) {
  useMetro();
  const [ladder, setLadder] = useState(false);
  const modeName = { beat: "", regroup: `accent every ${metro.group}`, poly: `${metro.poly.p}:${metro.poly.q}` }[metro.mode];
  return html`<div class="card metro">
    <div class="row">
      <button class=${"btn" + (metro.on ? " on" : "")} onClick=${() => metro.toggle()}>${metro.on ? "■" : "▶"} <kbd>M</kbd></button>
      <span class="bpm">♩ = <input type="number" value=${metro.bpm} onChange=${e => metro.set({ bpm: +e.target.value })} /></span>
      <button class="btn small" onClick=${() => metro.set({ bpm: metro.bpm - 2 })}>−</button><button class="btn small" onClick=${() => metro.set({ bpm: metro.bpm + 2 })}>+</button>
      ${metro.mode !== "poly" ? html`<select class="mini" value=${metro.beats} title="beats per bar" onChange=${e => metro.set({ beats: +e.target.value })}>${[1, 2, 3, 4, 5, 6, 7, 9, 12].map(x => html`<option value=${x}>${x} beats</option>`)}</select>
        <select class="mini" value=${metro.sub} title="clicks per beat" onChange=${e => metro.set({ sub: +e.target.value })}>${[1, 2, 3, 4, 6].map(x => html`<option value=${x}>${x === 1 ? "no sub" : "÷" + x}</option>`)}</select>` : null}
      ${modeName ? html`<button class="btn small on" title="back to a plain beat" onClick=${() => metro.set({ mode: "beat" })}>${modeName} ×</button>` : null}
      <button class=${"btn small" + (ladder ? " on" : "")} title="tempo ladder" onClick=${() => { const on = !ladder; setLadder(on); metro.set({ ladder: on ? { step: 2, every: 4, goal: (active && active.goal_tempo) || metro.bpm + 20 } : null }); }}>ladder</button>
    </div>
    ${ladder && metro.ladder ? html`<div class="row hint">+<input class="tiny" type="number" value=${metro.ladder.step} onChange=${e => metro.set({ ladder: { ...metro.ladder, step: +e.target.value } })} /> every
      <input class="tiny" type="number" value=${metro.ladder.every} onChange=${e => metro.set({ ladder: { ...metro.ladder, every: +e.target.value } })} /> bars, up to
      <input class="tiny" type="number" value=${metro.ladder.goal} onChange=${e => metro.set({ ladder: { ...metro.ladder, goal: +e.target.value } })} /></div>` : null}
  </div>`;
}
