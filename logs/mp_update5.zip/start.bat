@echo off
rem Music Practice - double-click to start. First run installs everything it needs (a few minutes).
setlocal EnableDelayedExpansion
cd /d "%~dp0"
if not exist "app\logs" mkdir "app\logs"
set "UVDIR=%USERPROFILE%\.local\bin"
set "PATH=%UVDIR%;%PATH%"
where uv >nul 2>nul
if errorlevel 1 (
  echo Installing the Python manager "uv" ^(one time^)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex" > "app\logs\install.log" 2>&1
  where uv >nul 2>nul
  if errorlevel 1 (
    echo Could not install uv. Details: app\logs\install.log
    pause
    exit /b 1
  )
)
echo Checking the Python environment ^(first run downloads about 600 MB, later runs are instant^)...
uv sync --directory app --python 3.12 >> "app\logs\install.log" 2>&1
if errorlevel 1 (
  echo Setup failed. Details: app\logs\install.log
  pause
  exit /b 1
)
echo Starting Music Practice. Keep this window open while you use it; close it to quit.
uv run --directory app --no-sync python -m practice %*
if errorlevel 1 pause
