"""Measure boxes on the page: homr gives each system's box and how many barlines it read there;
this finds where those barlines are (vertical strokes through the staves)."""
import numpy as np

def _rows(B, thr):
    prof = B.mean(1); rows = np.where(prof > thr)[0]; groups = []
    for r in rows:
        if groups and r - groups[-1][-1] <= 2: groups[-1].append(r)
        else: groups.append([r])
    return [float(np.mean(g)) for g in groups]

def staves(B):
    """Find 5-line staves (equally spaced line groups) inside a system crop."""
    for thr in (0.5, 0.4, 0.3, 0.2):
        ys = _rows(B, thr); found = []; i = 0
        while i + 4 < len(ys):
            g = np.diff(ys[i:i + 5])
            if g.min() > 3 and g.max() < 1.3 * g.min(): found.append((ys[i], ys[i + 4])); i += 5
            else: i += 1
        if len(found) >= 2 or (len(found) == 1 and thr == 0.2): return found
    return found

def deskew(B, max_deg=1.5, step=0.1):
    """Scans are often a little rotated (and differently in different parts of the page): straighten one system."""
    from scipy.ndimage import rotate
    small = B[::2, ::2].astype(np.float32)          # halving both axes keeps angles unchanged
    best, ba = -1, 0.0
    for a in np.arange(-max_deg, max_deg + 1e-9, step):
        p = rotate(small, a, reshape=False, order=0, prefilter=False).sum(1)
        v = float((p ** 2).sum())
        if v > best: best, ba = v, a
    if abs(ba) < 0.05: return B
    return rotate(B.astype(np.uint8), ba, reshape=False, order=0, prefilter=False) > 0

def find_barlines(gray, box, n_expected):
    """gray: uint8 page; box: (x0,y0,x1,y1) of one system; returns (xs, conf, (ytop, ybot), x_left)."""
    x0, y0, x1, y1 = [int(round(v)) for v in box]
    H, W = gray.shape
    pad = int(0.03 * W); x0 = max(0, x0 - pad); x1 = min(W, x1 + pad)
    y0 = max(0, y0); y1 = min(H, y1)
    B = gray[y0:y1, x0:x1] < 150
    B = deskew(B)
    st = staves(B)
    if not st: st = [(0.0, float(B.shape[0] - 1))]
    up = st[0]; lo = st[-1] if len(st) > 1 else st[0]
    space = max(4.0, (up[1] - up[0]) / 4.0)
    cov = lambda a, b: B[int(round(a)):int(round(b)) + 1].mean(0)
    cu = cov(*up); cl = cov(*lo)
    gap = cov(up[1] + 2, lo[0] - 2) if lo[0] > up[1] + 6 else np.ones(B.shape[1])
    both = np.minimum(cu, cl)
    # horizontal extent of the staff: where the top staff line is drawn
    r0 = max(0, int(round(up[0])) - 1); line_row = B[r0:r0 + 3].max(0)
    on = np.where(line_row)[0]
    xl, xr = (on[0], on[-1]) if len(on) else (0, B.shape[1] - 1)
    top = np.argsort(-both)[: max(3, n_expected * 2)]
    strong = top[both[top] > 0.9]
    connected = len(strong) > 0 and np.mean(gap[strong] > 0.85) > 0.6
    score = np.where(gap > 0.85, both, both * 0.5) if connected else both
    def groups(thr):
        cols = np.where(score > thr)[0]; gs = []
        for c in cols:
            if gs and c - gs[-1][-1] <= 1: gs[-1].append(c)
            else: gs.append([c])
        out = [(float(np.mean(g)), float(score[g].max())) for g in gs if len(g) <= 0.7 * space]
        merged = []
        for x, s in out:
            if merged and x - merged[-1][0] < 1.4 * space: merged[-1] = (x, max(s, merged[-1][1]))
            else: merged.append((x, s))
        return merged
    inner = lambda cs: [c for c in cs if xl + 3 * space < c[0] < xr - 2 * space]
    strong = inner(groups(0.97)) if connected else []
    n_expected = max(n_expected, len(strong) + 1)            # clear barlines beat OMR's count
    cands = []
    for thr in (0.95, 0.9, 0.85, 0.8, 0.7):
        cands = [c for c in groups(thr) if xl + 3 * space < c[0] < xr - 2 * space]   # not the system's left edge
        if len(cands) >= n_expected - 1: break
    # the system always ends with a barline at the end of the staff lines
    cands = sorted(cands, key=lambda c: -c[1])[:max(0, n_expected - 1)]
    cands = sorted(cands + [(float(xr), 1.0)], key=lambda c: c[0])
    xs = [x0 + c[0] for c in cands]; conf = [c[1] for c in cands]
    left = x0 + xl
    while len(xs) < n_expected:                              # not enough evidence: split the widest bar, flag it
        pts = [left] + xs; gaps = [(pts[i + 1] - pts[i], i) for i in range(len(pts) - 1)]
        g, i = max(gaps); xs.insert(i, (pts[i] + pts[i + 1]) / 2); conf.insert(i, 0.0)
    ytop = y0 + up[0] - 2.5 * space; ybot = y0 + lo[1] + 2.5 * space
    return xs, conf, (max(0, ytop), min(H, ybot)), left
