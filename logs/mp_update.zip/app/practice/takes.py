"""Your own takes (recorded in the app) and flags dropped while listening.

A take arrives as a browser recording (webm/opus, which seeks badly); it is converted to FLAC before analysis,
then aligned like any other recording, so it is bar-indexed. Flags are just (recording, time, bar, note).
"""
from pathlib import Path
from starlette.responses import JSONResponse
from starlette.routing import Route
from . import store

def J(obj, status=200): return JSONResponse(obj, status_code=status)

def to_flac(src):
    """Decode any audio file and write <stem>.flac next to it (mono, original rate). Returns the new path."""
    import av
    src = Path(src); dst = src.with_suffix(".flac")
    with av.open(str(src)) as inp:
        ast = inp.streams.audio[0]
        rate = ast.codec_context.sample_rate or 48000
        with av.open(str(dst), "w", format="flac") as out:
            ost = out.add_stream("flac", rate=rate); ost.layout = "mono"
            res = av.AudioResampler(format="s16", layout="mono", rate=rate)
            for frame in inp.decode(ast):
                frame.pts = None
                for f in res.resample(frame):
                    for pkt in ost.encode(f): out.mux(pkt)
            for f in res.resample(None):
                for pkt in ost.encode(f): out.mux(pkt)
            for pkt in ost.encode(None): out.mux(pkt)
    return dst

# ------------------------------------------------------------------ flags
async def api_flags(req):
    pid = int(req.path_params["pid"])
    return J(store.q("SELECT * FROM flags WHERE piece_id=? ORDER BY recording_id, t", (pid,)))

async def api_add_flag(req):
    rid = int(req.path_params["rid"]); body = await req.json()
    r = store.q1("SELECT piece_id FROM recordings WHERE id=?", (rid,))
    if not r: return J({"error": "no such recording"}, 404)
    i = store.ex("INSERT INTO flags(piece_id,recording_id,t,bar,pass,note,created) VALUES(?,?,?,?,?,?,?)",
                 (r["piece_id"], rid, float(body.get("t") or 0), body.get("bar"), body.get("pass"), body.get("note") or "", store.now()))
    return J(store.q1("SELECT * FROM flags WHERE id=?", (i,)))

async def api_update_flag(req):
    i = int(req.path_params["id"]); body = await req.json()
    for k in ("note", "bar", "t", "done"):
        if k in body: store.ex(f"UPDATE flags SET {k}=? WHERE id=?", (body[k], i))
    return J(store.q1("SELECT * FROM flags WHERE id=?", (i,)) or {})

async def api_delete_flag(req):
    store.ex("DELETE FROM flags WHERE id=?", (int(req.path_params["id"]),)); return J({"ok": True})

ROUTES = [
    Route("/api/pieces/{pid:int}/flags", api_flags),
    Route("/api/recordings/{rid:int}/flags", api_add_flag, methods=["POST"]),
    Route("/api/flags/{id:int}", api_update_flag, methods=["PATCH"]),
    Route("/api/flags/{id:int}", api_delete_flag, methods=["DELETE"]),
]
