import { h, render } from "./vendor/preact.js";
import { useState, useEffect, useRef, useMemo, useCallback, useReducer } from "./vendor/hooks.js";
import { html, api, fmt, ord, store, player, toast, usePlayerTick, romanOr, rangeLabel } from "./lib.js";
import { PracticePanel, PassageOverlay, HideOverlay, TestDialog, metro } from "./practice.js";
import { TimingLane } from "./timing.js";
import { RecordButton, toggleRecording, recorder, dropFlag, FlagsCard, FlagMarks } from "./record.js";
const MCOLS = ["var(--m0)", "var(--m1)", "var(--m2)", "var(--m3)", "var(--m4)", "var(--m5)"];

// ------------------------------------------------------------------ derived piece model
function derive(data) {
  if (!data || !data.score) return null;
  const bars = data.score.bars, byId = {}, order = {}, pageBars = {};
  const mvOf = data.movement_of || {};
  const deleted = new Set((data.structure && data.structure.deleted) || []);
  let k = 0;
  for (const b of bars) { byId[b.id] = b; (pageBars[b.page] = pageBars[b.page] || []).push(b); if (!deleted.has(b.id)) order[b.id] = k++; }
  const seq = bars.filter(b => !deleted.has(b.id)).map(b => b.id);
  const labels = data.labels || {};
  const mvNames = ((data.structure && data.structure.movements) || []).map((m, i) => m.name || `Movement ${i + 1}`);
  const label = id => { const m = mvOf[id]; const n = labels[id] ?? "?"; return mvNames.length > 1 && m != null ? `${romanOr(mvNames[m], m)} · ${n}` : `m. ${n}`; };
  return { bars, byId, order, seq, pageBars, labels, label, mvOf, mvNames, deleted, npages: data.score.pages.length, pages: data.score.pages };
}

// ------------------------------------------------------------------ app
function App() {
  const [pieces, setPieces] = useState([]);
  const [pid, setPid] = useState(store.get("pid", null));
  const [data, setData] = useState(null);
  const [mode, setMode] = useState("listen");
  const [page, setPage] = useState(1);
  const [sel, setSel] = useState(null);          // {a, b} bar ids (notated order), a <= b
  const [cursor, setCursor] = useState(null);    // bar id (for stepping when not playing)
  const [dialog, setDialog] = useState(null);    // 'palette' | 'import' | 'addrec' | 'help'
  const [jobsList, setJobs] = useState([]);
  const [editSystem, setEditSystem] = useState(null);
  const [passages, setPassages] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [hide, setHide] = useState(null);          // {a, b}: bars covered on the score
  const [testing, setTesting] = useState(null);    // passage being cold-tested
  const [pver, setPver] = useState(0);             // bump to refresh the practice plan
  const [flags, setFlags] = useState([]);
  const M = useMemo(() => derive(data), [data]);
  const active = passages.find(x => x.id === activeId) || null;
  usePlayerTick();

  const loadPieces = useCallback(() => api.get("/api/pieces").then(ps => { setPieces(ps); if (pid == null && ps.length) setPid(ps[0].id); return ps; }), [pid]);
  const loadPiece = useCallback(() => { if (pid == null) return; api.get(`/api/pieces/${pid}`).then(d => { if (d.error) { setPid(null); return; } setData(d); }); }, [pid]);
  useEffect(() => { loadPieces(); }, []);
  const loadPassages = useCallback(() => { if (pid == null) return; api.get(`/api/pieces/${pid}/passages`).then(ps => { if (Array.isArray(ps)) setPassages(ps); }); setPver(v => v + 1); }, [pid]);
  const loadFlags = useCallback(() => { if (pid == null) return; api.get(`/api/pieces/${pid}/flags`).then(fs => { if (Array.isArray(fs)) setFlags(fs); }); }, [pid]);
  useEffect(() => { store.set("pid", pid); setData(null); setSel(null); setCursor(null); setPage(1); setHide(null); loadPiece(); setPassages([]); loadPassages(); setFlags([]); loadFlags(); }, [pid]);
  useEffect(() => { if (M && data) player.setPiece(data.recordings, M.order); }, [data]);

  // job polling: refresh the piece when something relevant finishes
  const lastJobs = useRef("");
  useEffect(() => {
    let alive = true;
    const poll = async () => {
      if (!alive) return;
      try {
        const js = await api.get("/api/jobs"); setJobs(js);
        const sig = JSON.stringify(js.filter(j => j.piece_id === pid).map(j => [j.id, j.status]));
        if (sig !== lastJobs.current) { const had = lastJobs.current; lastJobs.current = sig; if (had) { loadPiece(); loadPieces(); } }
      } catch (e) {}
      setTimeout(poll, 1500);
    };
    poll(); return () => { alive = false; };
  }, [pid]);

  // follow playback: current bar -> page
  const p = player.pos();
  const curBar = p && p.k >= 0 ? p.bar : null;
  const spread = useRef(1);
  useEffect(() => { if (!(curBar && M && player.playing() && M.byId[curBar])) return; const cp = M.byId[curBar].page;
    const two = document.querySelectorAll(".page").length > 1;
    if (two ? (cp !== page && cp !== page + 1) : cp !== page) setPage(cp); }, [curBar]);

  // ---------------- selection helpers
  const selectBar = (id, extend) => {
    if (!M) return;
    if (extend && sel) { const o = M.order[id]; const oa = M.order[sel.a], ob = M.order[sel.b];
      const anchor = sel.anchor || sel.a; const oan = M.order[anchor];
      setSel(o < oan ? { a: id, b: anchor, anchor } : { a: anchor, b: id, anchor }); }
    else setSel({ a: id, b: id, anchor: id });
    setCursor(id);
  };
  const clickBar = (id, e) => {
    if (mode === "structure" || mode === "practice") { selectBar(id, e.shiftKey); return; }
    if (e.shiftKey && sel) { selectBar(id, true); return; }
    selectBar(id, false);
    const pass = e.altKey ? 2 : 1;
    if (!player.gotoBar(id, pass, true)) toast(`${player.rec ? player.rec.name : "This recording"} doesn't play ${M.label(id)}`);
  };
  // ---------------- passages
  const pending = useRef(null);
  const applyPassage = (p) => { setActiveId(p.id); setSel({ a: p.a, b: p.b, anchor: p.a }); setCursor(p.a); if (M && M.byId[p.a]) setPage(M.byId[p.a].page); };
  const openPassage = (p) => { setMode("practice"); if (p.piece_id !== pid) { pending.current = p; setPid(p.piece_id); } else applyPassage(p); };
  useEffect(() => { if (M && pending.current && pending.current.piece_id === pid) { applyPassage(pending.current); pending.current = null; } }, [M]);
  const newPassage = async () => {
    if (!sel) { toast("Select bars first: click a bar, then Shift+click the last one"); return; }
    const p = await api.send("POST", `/api/pieces/${pid}/passages`, { a: sel.a, b: sel.b });
    if (p.error) { toast(p.error); return; }
    setPassages(ps => [...ps, p]); setActiveId(p.id); setMode("practice"); loadPassages(); toast("Passage saved: name it in the panel");
  };
  const flagToPassage = async (f) => {
    const a = sel ? sel.a : f.bar, b = sel ? sel.b : f.bar;
    const p = await api.send("POST", `/api/pieces/${pid}/passages`, { a, b, name: f.note || "" });
    if (p.error) { toast(p.error); return; }
    await api.send("PATCH", `/api/flags/${f.id}`, { done: 1 }); loadFlags();
    setPassages(ps => [...ps, p]); setActiveId(p.id); setSel({ a, b, anchor: a }); setMode("practice"); loadPassages();
    toast(sel ? "Passage made from the selection" : "Passage made from the flagged bar: Shift+click to widen it, then “= selection”");
  };
  const recContext = mode === "practice" && active ? (active.name || rangeLabel(M, active.a, active.b)) : "";
  const practiceKey = useRef(null);
  const setLoop = (on) => { if (on && sel) { player.loop = { a: sel.a, b: sel.b }; player.gotoBar(sel.a, 1, true); } else player.loop = null; player.emit("state"); };

  // ---------------- keyboard
  useEffect(() => {
    const onKey = (e) => {
      if (e.target && (e.target.tagName === "INPUT" || e.target.tagName === "SELECT" || e.target.tagName === "TEXTAREA")) return;
      const k = e.key;
      if ((e.ctrlKey || e.metaKey) && k.toLowerCase() === "k") { e.preventDefault(); setDialog("palette"); return; }
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (dialog) { if (k === "Escape") setDialog(null); return; }
      if (testing) { if (k === "Escape") setTesting(null); return; }
      if (k === "?") { setDialog("help"); return; }
      if (k === "Tab") { e.preventDefault(); const ms = ["listen", "practice", "structure"]; setMode(m => ms[(ms.indexOf(m) + (e.shiftKey ? 2 : 1)) % 3]); return; }
      if (!M) return;
      if (k === "PageDown" || k === "j" || k === "J") { setPage(x => Math.min(M.npages, x + 1)); return; }
      if (k === "PageUp" || k === "k" || k === "K") { setPage(x => Math.max(1, x - 1)); return; }
      if (k === "Escape") { setSel(null); setEditSystem(null); setHide(null); if (player.loop) setLoop(false); return; }
      if (mode !== "structure") {
        if (k === "p" || k === "P") { newPassage(); return; }
        if (k === "r" || k === "R") { toggleRecording(pid, recContext).then(r => { if (r && r.id) loadPiece(); }); return; }
        if (k === "f" || k === "F") { dropFlag().then(f => { if (f && f.id) { loadFlags(); toast(`Flagged ${f.bar && M.byId[f.bar] ? M.label(f.bar) : fmt(f.t)} in ${player.rec.name}`); } }); return; }
        if (k === "m" || k === "M") { metro.toggle(); return; }
        if (k === "h" || k === "H") { const r = sel || active; setHide(hide ? null : (r ? { a: r.a, b: r.b } : null)); if (!r) toast("Select the bars to hide first"); return; }
      }
      if (mode === "practice" && practiceKey.current && practiceKey.current(e)) return;
      if (k === " ") { e.preventDefault(); if (!player.playing() && sel && !player.pos()?.bar) player.gotoBar(sel.a, 1, true); else player.toggle(); return; }
      if (/^[1-9]$/.test(k) && mode !== "structure") {
        const recs = data.recordings.filter(r => r.audio); const r = recs[+k - 1]; if (!r) return;
        const res = player.select(r.id); if (!res.ok) toast(`${r.name} doesn't play ${res.bar ? M.label(res.bar) : "this bar"}`); return; }
      if (k === "`") { if (player.prev != null) player.select(player.prev); return; }
      if (k === "ArrowRight" || k === "ArrowLeft") {
        e.preventDefault(); const d = k === "ArrowRight" ? 1 : -1;
        if (e.shiftKey) { const base = sel ? (M.order[sel.b] === M.order[cursor] ? sel.b : sel.a) : (curBar || cursor || M.seq[0]); const i = Math.min(M.seq.length - 1, Math.max(0, M.order[cursor || base] + d)); selectBar(M.seq[i], true); return; }
        if (mode === "listen" && player.rec && player.rec.occ.length && (player.playing() || curBar)) { player.step(d); return; }
        const i = Math.min(M.seq.length - 1, Math.max(0, (M.order[cursor] ?? -1) + d)); const id = M.seq[i]; selectBar(id, false); setPage(M.byId[id].page);
        if (mode === "listen") player.gotoBar(id, 1, player.playing()); return; }
      if (k === "Enter") { e.preventDefault(); const id = sel ? sel.a : (curBar || cursor); if (id) player.gotoBar(id, 1, true); return; }
      if (mode !== "structure") {
        if (k === "l" || k === "L") { if (!sel && curBar) { selectBar(curBar); } setLoop(!player.loop); return; }
        if (k === "-" || k === "_") { player.setRate(player.rate - 0.05); return; }
        if (k === "=" || k === "+") { player.setRate(player.rate + 0.05); return; }
        if (k === "0") { player.setRate(1); return; }
        if (k === "c" || k === "C") { player.ensureCtx(); player.click = !player.click; player.emit("state"); return; }
      }
      if (mode === "structure" && structureKey.current) structureKey.current(e);
    };
    window.addEventListener("keydown", onKey); return () => window.removeEventListener("keydown", onKey);
  }, [M, data, sel, cursor, dialog, mode, curBar, hide, active, testing, pid, recContext]);
  const structureKey = useRef(null);

  const activeJobs = jobsList.filter(j => j.status !== "failed");
  const piece = data && data.piece;

  return html`
    <div class="top">
      <span class="title" onClick=${() => setDialog("palette")} title="Library (Ctrl+K)">${piece ? (piece.title || "Untitled") : "Music Practice"}</span>
      ${piece && piece.composer ? html`<span class="sub">${piece.composer}</span>` : null}
      ${M ? html`<div class="seg"><button class=${mode === "listen" ? "on" : ""} onClick=${() => setMode("listen")}>Listen</button><button class=${mode === "practice" ? "on" : ""} onClick=${() => setMode("practice")}>Practice</button><button class=${mode === "structure" ? "on" : ""} onClick=${() => setMode("structure")}>Structure</button></div>` : null}
      <span class="spacer"></span>
      <${Jobs} jobs=${jobsList} data=${data} />
      ${M ? html`<${RecordButton} pid=${pid} context=${recContext} onSaved=${loadPiece} />` : null}
      <button class="btn" onClick=${() => setDialog("palette")}>Library <kbd>Ctrl K</kbd></button>
      <button class="btn" onClick=${() => setDialog("help")}>?</button>
    </div>
    ${!pieces.length && !piece ? html`<${Welcome} onImport=${() => setDialog("import")} />` :
      !M ? html`<div class="empty">${piece && piece.status !== "ready" ? html`<div class="row" style="justify-content:center"><span class="spin"></span> Reading the score… ${piece.message || ""}</div><div class="hint" style="margin-top:8px">The first reading of a score takes a few minutes (about half a minute per page). Recordings are prepared at the same time.</div>` : "Loading…"}</div>` :
      html`<div class="main">
        <${Score} M=${M} data=${data} page=${page} setPage=${setPage} sel=${sel} curBar=${curBar} mode=${mode} onBar=${clickBar}
                  editSystem=${editSystem} setEditSystem=${setEditSystem} reload=${loadPiece}
                  passages=${passages} active=${active} onPassage=${applyPassage} hide=${hide} flags=${flags} />
        <div class="side">
          ${mode === "practice"
            ? html`<${PracticePanel} M=${M} data=${data} sel=${sel} passages=${passages} active=${active} openPassage=${openPassage} setActive=${setActiveId}
                     reloadPassages=${loadPassages} setSel=${(s) => { setSel(s); if (s) { setCursor(s.a); if (M.byId[s.a]) setPage(M.byId[s.a].page); } }}
                     hide=${hide} setHide=${setHide} keyRef=${practiceKey} startTest=${(p) => setTesting(p)} version=${pver} />`
            : mode === "listen"
            ? html`<${ListenPanel} M=${M} data=${data} sel=${sel} setSel=${setSel} curBar=${curBar} onAdd=${() => setDialog("addrec")} setLoop=${setLoop} reload=${loadPiece}
                     flags=${flags} reloadFlags=${loadFlags} makePassage=${flagToPassage} />`
            : html`<${StructurePanel} M=${M} data=${data} sel=${sel} reload=${loadPiece} keyRef=${structureKey} editSystem=${editSystem} setEditSystem=${setEditSystem} />`}
        </div>
      </div>`}
    ${dialog === "palette" ? html`<${Palette} pieces=${pieces} pid=${pid} onPick=${(id) => { setPid(id); setDialog(null); }} onImport=${() => setDialog("import")} onClose=${() => setDialog(null)} reload=${loadPieces} />` : null}
    ${dialog === "import" ? html`<${ImportDialog} onClose=${() => setDialog(null)} onDone=${(id) => { setDialog(null); loadPieces(); setPid(id); }} />` : null}
    ${dialog === "addrec" ? html`<${AddRecording} pid=${pid} onClose=${() => setDialog(null)} onDone=${() => { setDialog(null); loadPiece(); }} />` : null}
    ${dialog === "help" ? html`<${Help} onClose=${() => setDialog(null)} />` : null}
    ${testing && M ? html`<${TestDialog} M=${M} passage=${testing} setHide=${setHide} onClose=${() => setTesting(null)} onDone=${() => loadPassages()} />` : null}
    <div class="toast" id="toast"></div>`;
}

// ------------------------------------------------------------------ top-level pieces
function Jobs({ jobs, data }) {
  const running = jobs.filter(j => j.status === "running")[0]; const queued = jobs.filter(j => j.status === "queued").length;
  const failed = jobs.filter(j => j.status === "failed");
  if (!running && !queued && !failed.length) return null;
  const names = { score: "Reading score", download: "Downloading", features: "Analysing audio", align: "Aligning", consensus: "Cross-checking recordings" };
  const recName = id => { const r = data && data.recordings.find(r => r.id === id); return r ? r.name : ""; };
  return html`<span class="jobs" title=${failed.map(f => `${names[f.kind] || f.kind} failed: ${f.error}`).join("\n")}>
    ${running ? html`<span class="spin"></span>${names[running.kind] || running.kind} ${recName(running.recording_id)} ${running.progress ? Math.round(running.progress * 100) + "%" : ""}` : null}
    ${queued ? html`<span class="pill">+${queued} queued</span>` : null}
    ${failed.length ? html`<span class="pill status-bad">${failed.length} failed</span>` : null}</span>`;
}

function Welcome({ onImport }) {
  return html`<div class="welcome"><h1>Music Practice</h1>
    <p class="muted">Start with a score: a PDF from IMSLP works well. The tool reads it, finds the bars, and lines up any recordings you add.</p>
    <button class="btn primary" onClick=${onImport}>Import a score (PDF)</button></div>`;
}

function Palette({ pieces, pid, onPick, onImport, onClose, reload }) {
  const [q, setQ] = useState(""); const [i, setI] = useState(0); const inp = useRef();
  useEffect(() => { inp.current && inp.current.focus(); reload(); }, []);
  const items = pieces.filter(p => (p.title + " " + (p.composer || "")).toLowerCase().includes(q.toLowerCase()));
  const key = e => { if (e.key === "ArrowDown") { e.preventDefault(); setI(x => Math.min(items.length - 1, x + 1)); } if (e.key === "ArrowUp") { e.preventDefault(); setI(x => Math.max(0, x - 1)); }
    if (e.key === "Enter" && items[i]) onPick(items[i].id); if (e.key === "Escape") onClose(); };
  return html`<div class="scrim" onClick=${e => e.target === e.currentTarget && onClose()}><div class="dialog palette">
    <input ref=${inp} placeholder="Find a piece…" value=${q} onInput=${e => { setQ(e.target.value); setI(0); }} onKeyDown=${key} />
    <div class="plist">${items.map((p, k) => html`<div class=${"pitem" + (k === i ? " on" : "")} onClick=${() => onPick(p.id)}>
        <b>${p.title}</b><span class="muted">${p.composer || ""}</span><span class="meta">${p.status !== "ready" ? p.status + " · " : ""}${p.recordings} recording${p.recordings === 1 ? "" : "s"}</span></div>`)}
      ${!items.length ? html`<div class="empty">No pieces yet.</div>` : null}</div>
    <div class="actions"><button class="btn" onClick=${onImport}>Import a score (PDF)…</button></div></div></div>`;
}

function ImportDialog({ onClose, onDone }) {
  const [file, setFile] = useState(null); const [title, setTitle] = useState(""); const [composer, setComposer] = useState("");
  const [from, setFrom] = useState(""); const [to, setTo] = useState(""); const [busy, setBusy] = useState(false);
  const go = async () => {
    if (!file) return; setBusy(true);
    const fd = new FormData(); fd.append("pdf", file); fd.append("title", title); fd.append("composer", composer);
    if (from) fd.append("page_from", from); if (to) fd.append("page_to", to);
    const r = await api.form("/api/pieces", fd);
    onDone(r.id);
  };
  return html`<div class="scrim" onClick=${e => e.target === e.currentTarget && onClose()}><div class="dialog"><h3>Import a score</h3>
    <div class="fields">
      <label>PDF file<input type="file" accept="application/pdf" onChange=${e => { const f = e.target.files[0]; setFile(f); if (f && !title) setTitle(f.name.replace(/\.pdf$/i, "").replace(/^IMSLP\d+-PMLP\d+-/, "").replace(/_/g, " ")); }} /></label>
      <label>Title<input value=${title} onInput=${e => setTitle(e.target.value)} /></label>
      <label>Composer<input value=${composer} onInput=${e => setComposer(e.target.value)} /></label>
      <div class="row hint">Only pages <input style="width:60px" placeholder="first" value=${from} onInput=${e => setFrom(e.target.value)} /> to <input style="width:60px" placeholder="last" value=${to} onInput=${e => setTo(e.target.value)} /> (optional: e.g. one movement of a long PDF)</div>
    </div>
    <p class="hint">Reading takes about half a minute per page. You can keep using the app meanwhile.</p>
    <div class="actions"><button class="btn" onClick=${onClose}>Cancel</button><button class="btn primary" disabled=${!file || busy} onClick=${go}>${busy ? "Uploading…" : "Import"}</button></div></div></div>`;
}

function AddRecording({ pid, onClose, onDone }) {
  const [tab, setTab] = useState("youtube"); const [url, setUrl] = useState(""); const [file, setFile] = useState(null);
  const [name, setName] = useState(""); const [kind, setKind] = useState("reference"); const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true);
    if (tab === "youtube") await api.send("POST", `/api/pieces/${pid}/recordings`, { url, name, kind });
    else { const fd = new FormData(); fd.append("file", file); fd.append("name", name); fd.append("kind", kind); await api.form(`/api/pieces/${pid}/recordings`, fd); }
    onDone();
  };
  return html`<div class="scrim" onClick=${e => e.target === e.currentTarget && onClose()}><div class="dialog"><h3>Add a recording</h3>
    <div class="seg" style="width:max-content;margin-bottom:10px"><button class=${tab === "youtube" ? "on" : ""} onClick=${() => setTab("youtube")}>YouTube link</button><button class=${tab === "file" ? "on" : ""} onClick=${() => setTab("file")}>Audio file</button></div>
    <div class="fields">
      ${tab === "youtube" ? html`<label>Link<input placeholder="https://www.youtube.com/watch?v=…" value=${url} onInput=${e => setUrl(e.target.value)} /></label>`
        : html`<label>File (mp3, m4a, wav, webm…)<input type="file" accept="audio/*,video/*" onChange=${e => { const f = e.target.files[0]; setFile(f); if (f && !name) setName(f.name.replace(/\.[^.]+$/, "")); }} /></label>`}
      <label>Name (performer)<input value=${name} placeholder=${tab === "youtube" ? "from the video title if empty" : ""} onInput=${e => setName(e.target.value)} /></label>
      <label>Whose recording?<select value=${kind} onChange=${e => setKind(e.target.value)}><option value="reference">A performer (reference)</option><option value="mine">Mine</option></select></label>
    </div>
    <p class="hint">It is downloaded, analysed, and lined up with the score automatically, including which repeats were taken.</p>
    <div class="actions"><button class="btn" onClick=${onClose}>Cancel</button><button class="btn primary" disabled=${busy || (tab === "youtube" ? !url : !file)} onClick=${go}>${busy ? "Adding…" : "Add"}</button></div></div></div>`;
}

function Help({ onClose }) {
  const rows = [["Space", "play / pause"], ["click a bar", "Listen: play from there (Alt+click: the 2nd time through). Practice, Structure: select it"], ["Shift+click, Shift+← →", "select a range of bars"],
    ["L", "loop the selection"], ["Enter", "play from the selection (or the current bar)"], ["← →", "previous / next bar"], ["1 – 9", "switch recording at the same spot"],
    ["`", "back to the previous recording"], ["−  =  0", "slower / faster / normal speed (pitch stays)"], ["C", "click on every downbeat (to check the alignment)"], ["F", "flag this spot in the recording"], ["R", "record yourself (again to stop)"],
    ["J K, PgUp PgDn", "turn pages"], ["P", "save the selection as a passage to practise"], ["T", "cold-test the passage (then 1–4 to rate)"],
    ["[  ]", "Practice: other technique cards"], ["M", "metronome on / off"], ["H", "hide the selected bars on the score (memory)"],
    ["Tab", "Listen → Practice → Structure"], ["Esc", "clear selection, stop looping, show hidden bars"], ["Ctrl+K", "library"]];
  return html`<div class="scrim" onClick=${e => e.target === e.currentTarget && onClose()}><div class="dialog"><h3>Keys</h3>
    <div class="help">${rows.map(([k, v]) => html`<span><kbd>${k}</kbd></span><span>${v}</span>`)}</div>
    <p class="hint">Structure mode: click a bar, then use the buttons (or keys shown on them) to mark repeats, endings, D.C., new movements, meter changes, or to fix barlines.</p>
    <div class="actions"><button class="btn" onClick=${onClose}>Close</button></div></div></div>`;
}

// ------------------------------------------------------------------ score view
function Score(props) {
  const { M, page, setPage, curBar } = props;
  const wrap = useRef(); const [box, setBox] = useState({ w: 800, h: 700 });
  useEffect(() => { const ro = new ResizeObserver(es => { const r = es[0].contentRect; setBox({ w: r.width, h: r.height }); }); ro.observe(wrap.current); return () => ro.disconnect(); }, []);
  const pg = M.pages[page - 1] || M.pages[0]; const aspect = pg.w / pg.h;
  const pw = box.h * aspect; const two = M.npages > 1 && box.w >= 2 * pw + 8;
  // in a two-page spread, show (page, page+1); keep the current bar visible
  const left = two ? Math.min(page, M.npages - 1) : page;
  const shown = two ? [left, left + 1] : [page];
  return html`<div class="scorewrap" ref=${wrap}>
    ${shown.map(n => html`<${Page} key=${n} ...${props} n=${n} dispW=${Math.min(pw, two ? (box.w - 8) / 2 : box.w)} />`)}
    <div class="pagenav" style="position:absolute;left:8px;bottom:6px;z-index:2"><button onClick=${() => setPage(Math.max(1, page - (two ? 2 : 1)))}>‹</button><button onClick=${() => setPage(Math.min(M.npages, page + (two ? 2 : 1)))}>›</button></div>
  </div>`;
}

function Page({ M, data, n, dispW, sel, curBar, mode, onBar, editSystem, setEditSystem, reload, passages, active, onPassage, hide, flags }) {
  const pg = M.pages[n - 1]; const bars = M.pageBars[n] || [];
  const pid = data.piece.id; const W = pg.w, H = pg.h; const k = W / Math.max(100, dispW);
  const oa = sel ? M.order[sel.a] : null, ob = sel ? M.order[sel.b] : null;
  const mk = (data.structure && data.structure.markup) || {};
  const mvStarts = new Set(((data.structure && data.structure.movements) || []).map(m => m.start));
  const spreadOf = useMemo(() => {   // bars where the recordings disagree (active recording)
    const out = {}; const r = player.rec; if (!r) return out;
    for (const o of r.occ) { if (o[4] != null && o[4] > 0.12 * Math.max(0.05, o[3] - o[2])) out[o[0]] = 1; }
    return out; }, [data, player.act]);
  const svgRef = useRef();
  const es = editSystem && editSystem.page === n ? data.score.systems.find(s => s.page === editSystem.page && s.idx === editSystem.idx) : null;
  const [drag, setDrag] = useState(null);
  const [lines, setLines] = useState(null);
  useEffect(() => { setLines(es ? [...es.barlines] : null); }, [editSystem, data]);
  const toX = (e) => { const r = svgRef.current.getBoundingClientRect(); return (e.clientX - r.left) / r.width; };
  const saveLines = async (ls) => { await api.send("PUT", `/api/pieces/${pid}/barlines`, { page: es.page, idx: es.idx, barlines: ls }); reload(); };
  const fs = 11 * k;
  return html`<div class="page" style=${`aspect-ratio:${W}/${H}`}>
      <img src=${`/api/pieces/${pid}/pages/${n}`} draggable="false" />
      <svg ref=${svgRef} viewBox=${`0 0 ${W} ${H}`} preserveAspectRatio="none"
        onMouseMove=${e => { if (drag != null && lines) { const x = Math.min(0.999, Math.max(0.001, toX(e))); const ls = [...lines]; ls[drag] = x; setLines(ls); } }}
        onMouseUp=${() => { if (drag != null && lines) { setDrag(null); saveLines(lines); } }}>
        ${bars.map(b => {
          const [x0, y0, x1, y1] = b.box; const o = M.order[b.id];
          const deleted = M.deleted.has(b.id);
          const cls = ["bar", mode === "structure" ? "edit" : "", o != null && sel && o >= oa && o <= ob ? "sel" : "", b.id === curBar ? "cur" : "",
                       deleted ? "deleted" : "", mode === "structure" && mvStarts.has(b.id) ? "mvstart" : "", mode === "listen" && spreadOf[b.id] ? "low" : ""].join(" ");
          return html`<rect class=${cls} vector-effect="non-scaling-stroke" x=${x0 * W + 2 * k} y=${y0 * H} width=${Math.max(2, (x1 - x0) * W - 4 * k)} height=${(y1 - y0) * H} rx=${4 * k}
                        onClick=${e => { if (es && es.idx === b.system) { const ls = [...lines, toX(e)].sort((a, c) => a - c); setLines(ls); saveLines(ls); return; } onBar(b.id, e); }}
                        onDblClick=${() => { if (mode === "structure") setEditSystem({ page: b.page, idx: b.system }); }}>
                        <title>${deleted ? "not a bar (removed)" : M.label(b.id)}</title></rect>`;
        })}
        ${bars.map(b => {
          const [x0, y0, x1, y1] = b.box; const showLbl = mode === "structure" || b.idx === 0 || b.id === curBar;
          const m = mk[b.id] || {}; const marks = [];
          if (m.repeat_start) marks.push("|:"); if (m.repeat_end) marks.push(":|"); if (m.ending) marks.push(m.ending + "."); if (m.fine) marks.push("Fine");
          if (m.dc) marks.push("D.C."); if (m.ds) marks.push("D.S."); if (m.segno) marks.push("segno"); if (m.coda) marks.push("coda"); if (m.to_coda) marks.push("to coda"); if (m.meter) marks.push(m.meter);
          return html`<g>${showLbl && M.labels[b.id] != null && !M.deleted.has(b.id) ? html`<text class="lbl" style=${`font-size:${fs}px`} x=${x0 * W + 5 * k} y=${y0 * H + fs * 1.05}>${M.labels[b.id]}</text>` : null}
            ${mode === "structure" && marks.length ? html`<text class="mk" style=${`font-size:${fs * 1.1}px`} x=${x0 * W + 5 * k} y=${y1 * H - 4 * k}>${marks.join(" ")}</text>` : null}</g>`;
        })}
        ${mode === "practice" ? html`<${PassageOverlay} M=${M} bars=${bars} passages=${passages} active=${active} W=${W} H=${H} k=${k} onPick=${onPassage} />` : null}
        <${HideOverlay} M=${M} bars=${bars} hide=${hide} W=${W} H=${H} k=${k} />
        ${mode === "listen" ? html`<${FlagMarks} M=${M} bars=${bars} flags=${flags} W=${W} H=${H} k=${k} />` : null}
        ${es && lines ? lines.map((x, j) => html`<line class="bl-handle" vector-effect="non-scaling-stroke" x1=${x * W} x2=${x * W} y1=${es.y0 * H} y2=${es.y1 * H}
            onMouseDown=${e => { e.stopPropagation(); setDrag(j); }}
            onContextMenu=${e => { e.preventDefault(); const ls = lines.filter((_, i) => i !== j); setLines(ls); saveLines(ls); }}><title>drag to move · right-click to remove</title></line>`) : null}
      </svg>
      <span class="pg">p. ${n} / ${M.npages}</span>
    </div>`;
}

// ------------------------------------------------------------------ listen panel
function formSummary(r, M) {
  const occ = r.alignment ? r.alignment.occ : []; if (!occ.length) return "";
  // performance order as spans of consecutive bars, per movement
  const spans = []; let cur = null;
  for (const o of occ) {
    const i = M.order[o[0]]; if (i == null) continue;
    if (cur && i === cur.bi + 1) { cur.b = o[0]; cur.bi = i; } else { cur = { a: o[0], b: o[0], ai: i, bi: i }; spans.push(cur); }
  }
  const lab = id => M.labels[id] ?? "?";
  const mvs = [];
  for (const s of spans) { const m = M.mvOf[s.a]; const name = M.mvNames.length > 1 ? romanOr(M.mvNames[m], m) + ": " : ""; mvs.push(name + (s.a === s.b ? lab(s.a) : `${lab(s.a)}–${lab(s.b)}`)); }
  return mvs.join(" · ");
}

function RecStrip({ r, M, active, flags }) {
  const occ = r.alignment ? r.alignment.occ : []; const T = Math.max(1, r.duration || (occ.length ? occ[occ.length - 1][3] + 2 : 1));
  const t = active ? player.time() : null;
  return html`<div class="strip">${occ.map((o, k) => {
      const w = Math.min(20, o[3] - o[2]); if (w <= 0) return null;
      return html`<i class=${o[1] > 1 ? "p2" : ""} style=${`left:${100 * o[2] / T}%;width:${100 * w / T + 0.05}%;background:${MCOLS[(M.mvOf[o[0]] || 0) % MCOLS.length]}`}></i>`; })}
    ${(flags || []).filter(f => f.recording_id === r.id && !f.done).map(f => html`<b class="ft" style=${`left:${100 * f.t / T}%`}></b>`)}
    ${t != null ? html`<div class="ph" style=${`left:${100 * t / T}%`}></div>` : null}</div>`;
}

function ListenPanel({ M, data, sel, setSel, curBar, onAdd, setLoop, reload, flags, reloadFlags, makePassage }) {
  const recs = data.recordings; const playable = recs.filter(r => r.audio);
  const p = player.pos(); const r = player.rec;
  const bar = p && p.k >= 0 ? p.bar : null;
  const twice = bar && r ? player.passes(r.id, bar) > 1 : false;
  const [menu, setMenu] = useState(null);
  const [tab, setTab] = useState(store.get("listenTab", "flags")); useEffect(() => store.set("listenTab", tab), [tab]);
  const statusText = rr => ({ queued: "queued", downloading: "downloading…", processing: "analysing…", aligning: "aligning…", waiting: "waiting to align", failed: "failed", new: "waiting" }[rr.status] || "");
  return html`
    <div class="card"><h2>Recordings<span class="r"><button class="btn small" onClick=${onAdd}>+ Add</button></span></h2>
      ${recs.length ? recs.map((rr) => { const k = playable.indexOf(rr);
        return html`<div class=${"rec" + (player.act === rr.id ? " on" : "")} onClick=${() => { if (!rr.audio) return; const res = player.select(rr.id); if (!res.ok) toast(`${rr.name} doesn't play ${res.bar ? M.label(res.bar) : "this bar"}`); }}
            onContextMenu=${e => { e.preventDefault(); setMenu(menu === rr.id ? null : rr.id); }} title=${formSummary(rr, M)}>
          <span class="key">${k >= 0 ? k + 1 : "·"}</span>
          <span class=${"nm" + (rr.kind === "mine" ? " mine" : "")}>${rr.name || "…"}</span>
          ${rr.alignment && rr.alignment.occ.length ? html`<${RecStrip} r=${rr} M=${M} active=${player.act === rr.id} flags=${flags} />` : html`<span class=${"st" + (rr.status === "failed" ? " status-bad" : "")} title=${rr.message || ""}>${statusText(rr) || (rr.status === "ready" ? "not in this piece?" : "")}</span>`}
          <span class="st">${rr.alignment && rr.alignment.stale ? "re-aligning…" : ""}</span>
        </div>
        ${menu === rr.id ? html`<${RecMenu} r=${rr} onDone=${() => { setMenu(null); reload(); }} />` : null}`; })
      : html`<div class="hint">No recordings yet. Add a YouTube link or an audio file, yours or a performer's.</div>`}
      ${recs.length ? html`<div class="hint" style="margin-top:4px">Right-click a recording for options.</div>` : null}
    </div>
    <div class="card now">
      <div class="big">${bar ? M.label(bar) : (sel ? M.label(sel.a) : "—")}${twice ? html`<small>${ord(p.pass)} time</small>` : null}<small>${fmt(player.time())}</small></div>
      <div class="controls">
        <button class=${"btn" + (player.playing() ? " on" : "")} onClick=${() => { if (!player.playing() && sel && !bar) player.gotoBar(sel.a, 1, true); else player.toggle(); }}>${player.playing() ? "Pause" : "Play"} <kbd>Space</kbd></button>
        <button class=${"btn" + (player.loop ? " on" : "")} disabled=${!sel} onClick=${() => setLoop(!player.loop)}>Loop <kbd>L</kbd></button>
        <button class="btn" onClick=${() => player.setRate(player.rate - 0.05)}>−</button><span class="speed">${Math.round(player.rate * 100)}%</span><button class="btn" onClick=${() => player.setRate(player.rate + 0.05)}>+</button>
        <button class=${"btn" + (player.click ? " on" : "")} onClick=${() => { player.ensureCtx(); player.click = !player.click; player.emit("state"); }}>Click <kbd>C</kbd></button>
      </div>
      <div class="bar-info" style="width:100%">${sel ? html`Selected: ${M.label(sel.a)}${sel.b !== sel.a ? html` – ${M.label(sel.b)}` : ""}${player.loop ? " · looping" : " · L to loop"}` : html`Click a bar to play from there. Shift+click to select a passage.`}</div>
    </div>
    <div class="card grow"><h2><div class="seg mini"><button class=${tab === "flags" ? "on" : ""} onClick=${() => setTab("flags")}>Flags${flags.filter(f => !f.done).length ? ` (${flags.filter(f => !f.done).length})` : ""}</button><button class=${tab === "timing" ? "on" : ""} onClick=${() => setTab("timing")}>Timing</button></div></h2>
      ${tab === "flags" ? html`
        <div class="form-summary" title="the form this recording takes">${r ? html`<b>${r.name}:</b> ${formSummary(data.recordings.find(x => x.id === r.id) || {}, M) || "not aligned yet"}` : "Add a recording to hear the score."}</div>
        <${FlagsCard} M=${M} data=${data} flags=${flags} reload=${reloadFlags} makePassage=${makePassage} />`
      : html`<${TimingLane} M=${M} data=${data} range=${sel || (bar ? { a: bar, b: bar } : null)} />`}
    </div>`;
}

function RecMenu({ r, onDone }) {
  const [name, setName] = useState(r.name || ""); const [a, setA] = useState(r.range_start ?? ""); const [b, setB] = useState(r.range_end ?? "");
  const save = async () => { await api.send("PATCH", `/api/recordings/${r.id}`, { name, range_start: a === "" ? null : +a, range_end: b === "" ? null : +b }); onDone(); };
  return html`<div class="card" style="margin:4px 0 6px 26px;padding:8px">
    <div class="fields" style="display:grid;gap:6px">
      <label class="hint">Name <input value=${name} onInput=${e => setName(e.target.value)} /></label>
      <div class="row hint">Only use from <input style="width:70px" placeholder="0" value=${a} onInput=${e => setA(e.target.value)} /> to <input style="width:70px" placeholder="end" value=${b} onInput=${e => setB(e.target.value)} /> seconds</div>
      ${r.chapters && r.chapters.length ? html`<div class="hint">Chapters: ${r.chapters.map(c => html`<button class="btn small" onClick=${() => { setA(Math.round(c.start_time)); setB(Math.round(c.end_time)); }}>${c.title}</button> `)}</div>` : null}
    </div>
    <div class="row" style="margin-top:6px"><button class="btn small primary" onClick=${save}>Save</button>
      <button class="btn small" onClick=${async () => { await api.send("POST", `/api/recordings/${r.id}/realign`); onDone(); }}>Re-align</button>
      <span class="spacer"></span><button class="btn small" onClick=${async () => { if (confirm(`Remove "${r.name}" from this piece?`)) { await api.send("DELETE", `/api/recordings/${r.id}`); onDone(); } }}>Remove</button></div></div>`;
}

// ------------------------------------------------------------------ structure panel
function StructurePanel({ M, data, sel, reload, keyRef, editSystem, setEditSystem }) {
  const pid = data.piece.id; const st = data.structure || { movements: [], markup: {}, deleted: [] };
  const [dirty, setDirty] = useState(null);
  const s = dirty || st;
  const save = async (ns) => { setDirty(ns); await api.send("PUT", `/api/pieces/${pid}/structure`, ns); setDirty(null); reload(); };
  const bar = sel ? sel.a : null; const m = (bar && s.markup[bar]) || {};
  const setMark = (key, val) => { const mk = { ...s.markup }; const cur = { ...(mk[bar] || {}) };
    if (val == null || val === 0 || val === "" || val === false) delete cur[key]; else cur[key] = val;
    if (Object.keys(cur).length) mk[bar] = cur; else delete mk[bar]; save({ ...s, markup: mk }); };
  const toggle = (key, val = 1) => setMark(key, m[key] ? null : val);
  const newMovement = () => { if (!bar || s.movements.some(x => x.start === bar)) return;
    const mv = [...s.movements, { name: "", start: bar, meter: (s.movements[0] && s.movements[0].meter) || "4/4", pickup: false }];
    mv.sort((a, b) => M.order[a.start] - M.order[b.start]); save({ ...s, movements: mv }); };
  const delBar = () => { const d = new Set(s.deleted || []); d.has(bar) ? d.delete(bar) : d.add(bar); save({ ...s, deleted: [...d] }); };
  keyRef.current = (e) => {
    if (!bar) return; const k = e.key.toLowerCase();
    if (k === "[") toggle("repeat_start"); else if (k === "]") toggle("repeat_end"); else if (k === "1") setMark("ending", m.ending === 1 ? null : 1);
    else if (k === "2") setMark("ending", m.ending === 2 ? null : 2); else if (k === "f") toggle("fine"); else if (k === "d") toggle("dc");
    else if (k === "n") newMovement(); else if (k === "delete" || k === "backspace") delBar();
    else if (k === "b") { const b = M.byId[bar]; setEditSystem(editSystem ? null : { page: b.page, idx: b.system }); }
  };
  return html`
    <div class="card"><h2>Movements</h2>
      ${s.movements.map((mv, i) => html`<div class="mvrow">
        <input value=${mv.name} placeholder=${`Movement ${i + 1}`} onChange=${e => { const x = s.movements.map((y, j) => j === i ? { ...y, name: e.target.value } : y); save({ ...s, movements: x }); }} />
        <input value=${mv.meter} title="time signature" onChange=${e => { const x = s.movements.map((y, j) => j === i ? { ...y, meter: e.target.value } : y); save({ ...s, movements: x }); }} />
        <label class="hint" title="the first bar is a pickup (upbeat)"><input type="checkbox" checked=${!!mv.pickup} onChange=${e => { const x = s.movements.map((y, j) => j === i ? { ...y, pickup: e.target.checked } : y); save({ ...s, movements: x }); }} /> pickup</label>
        ${i > 0 ? html`<button class="btn small" title="merge into the previous movement" onClick=${() => save({ ...s, movements: s.movements.filter((_, j) => j !== i) })}>×</button>` : html`<span></span>`}
      </div>`)}
      <div class="hint">Starts at the green-outlined bars. Meter like 3/4, 6/8, C = 4/4.</div>
    </div>
    <div class="card"><h2>Selected bar ${bar ? html`<span class="pill">${M.label(bar)}</span>` : null}</h2>
      ${bar ? html`<div class="tools">
          <button class=${"btn" + (m.repeat_start ? " on" : "")} onClick=${() => toggle("repeat_start")}>𝄆 repeat from here <kbd>[</kbd></button>
          <button class=${"btn" + (m.repeat_end ? " on" : "")} onClick=${() => toggle("repeat_end")}>𝄇 repeat back <kbd>]</kbd></button>
          <button class=${"btn" + (m.ending === 1 ? " on" : "")} onClick=${() => setMark("ending", m.ending === 1 ? null : 1)}>1st ending <kbd>1</kbd></button>
          <button class=${"btn" + (m.ending === 2 ? " on" : "")} onClick=${() => setMark("ending", m.ending === 2 ? null : 2)}>2nd ending <kbd>2</kbd></button>
          <button class=${"btn" + (m.fine ? " on" : "")} onClick=${() => toggle("fine")}>Fine <kbd>F</kbd></button>
          <button class=${"btn" + (m.dc ? " on" : "")} onClick=${() => toggle("dc")}>D.C. <kbd>D</kbd></button>
          <button class=${"btn" + (m.ds ? " on" : "")} onClick=${() => toggle("ds")}>D.S.</button>
          <button class=${"btn" + (m.segno ? " on" : "")} onClick=${() => toggle("segno")}>𝄋 segno</button>
          <button class=${"btn" + (m.to_coda ? " on" : "")} onClick=${() => toggle("to_coda")}>to coda</button>
          <button class=${"btn" + (m.coda ? " on" : "")} onClick=${() => toggle("coda")}>𝄌 coda</button>
          <button class="btn" onClick=${newMovement}>New movement here <kbd>N</kbd></button>
          <button class=${"btn" + (M.deleted.has(bar) ? " on" : "")} onClick=${delBar} title="for something that was mistaken for a bar">Not a bar <kbd>Del</kbd></button>
          <button class=${"btn" + (editSystem ? " on" : "")} onClick=${() => { const b = M.byId[bar]; setEditSystem(editSystem ? null : { page: b.page, idx: b.system }); }}>Fix barlines in this line <kbd>B</kbd></button>
          <label class="hint row">Meter change here <input style="width:60px" value=${m.meter || ""} placeholder="—" onChange=${e => setMark("meter", e.target.value.trim())} /></label>
        </div>
        ${editSystem ? html`<p class="hint">Barline editing: click inside the line to add a barline, drag a red line to move it, right-click it to remove it. Esc when done.</p>` : null}`
        : html`<div class="hint">Click a bar on the score. Marks are applied to the selected bar: "repeat back" and endings go on the last bar of a section.</div>`}
    </div>
    <div class="card grow"><h2>How this is used</h2><div class="hint">Every change re-aligns this piece's recordings in the background, so each recording's repeats, D.C. and cuts are found from the audio itself.
      ${dirty ? html`<div class="row" style="margin-top:6px"><span class="spin"></span> saving…</div>` : null}</div>
      <div class="row" style="margin-top:auto"><button class="btn small" onClick=${async () => { if (confirm("Read the score again from scratch? Structure marks will be reset.")) { await api.send("POST", `/api/pieces/${pid}/reread`); reload(); } }}>Read the score again</button></div>
    </div>`;
}

render(html`<${App} />`, document.getElementById("app"));
